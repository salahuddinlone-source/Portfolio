CREATE DATABASE UniversityDB;
USE UniversityDB;
CREATE TABLE Students (
    StudentID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    Email NVARCHAR(100) NOT NULL);
    INSERT INTO Students (FirstName, LastName, Email)
VALUES 
('Ali', 'Khan', 'ali@gmail.com'),
('Sara', 'Ahmed', 'sara@gmail.com');
SELECT * FROM  Students;
CREATE TABLE Courses (
    CourseID INT IDENTITY(1,1) PRIMARY KEY,
    CourseName NVARCHAR(100) NOT NULL,
    Credits INT NOT NULL);

INSERT INTO Courses (CourseName, Credits)
VALUES
('Database Systems', 4),
('Data Science', 3);

SELECT * FROM Courses;
CREATE TABLE Enrollments (
    EnrollmentID INT IDENTITY(1,1) PRIMARY KEY,
    StudentID INT,
    CourseID INT,
    EnrollmentDate DATE,
    CONSTRAINT FK_Student
        FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    CONSTRAINT FK_Course
        FOREIGN KEY (CourseID) REFERENCES Courses(CourseID));
INSERT INTO Enrollments (StudentID, CourseID, EnrollmentDate)
VALUES
(1, 1, '2024-01-10'),
(2, 2, '2024-01-12');

SELECT 
    S.FirstName,
    S.LastName,
    C.CourseName,
    E.EnrollmentDate
FROM Enrollments E
JOIN Students S ON E.StudentID = S.StudentID
JOIN Courses C ON E.CourseID = C.CourseID;





