from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
import time
import csv

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

driver.get("https://quotes.toscrape.com")
time.sleep(2)

data = []

while True:

    quotes = driver.find_elements(By.CLASS_NAME, "quote")

    for quote in quotes:
        text = quote.find_element(By.CLASS_NAME, "text").text
        author = quote.find_element(By.CLASS_NAME, "author").text
        
        tags_elements = quote.find_elements(By.CLASS_NAME, "tag")
        tags = ", ".join([tag.text for tag in tags_elements])

        data.append([text, author, tags])

    try:
        next_button = driver.find_element(By.LINK_TEXT, "Next")
        next_button.click()
        time.sleep(2)
    except:
        break

input("Press Enter to close browser...")
driver.quit()

with open("quotes_tags.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["Quote", "Author", "Tags"])
    writer.writerows(data)

print("Data saved to quotes_tags.csv")